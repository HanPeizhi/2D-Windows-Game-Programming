//icon, cursor
#define ID_ICON1					102
#define ID_CROSSHAIR				200

// sound
#define SOUND_ID_CREATE			1
#define SOUND_ID_MUSIC			2

// string table
#define ID_STR_START_GAME		16
#define ID_STR_LOAD_GAME		17
#define ID_STR_SAVE_GAME		18
#define ID_STR_OPTIONS			19
#define	ID_STR_EXIT				20
